#include <stdio.h>
#include <stdlib.h>

char* generate_flag();

int main(){
  char* result = "No flag for you!";
  asm("jmp .+7"); // Darn you ice king!
  result = generate_flag();
  printf("%s", result);
  return 0;
}
